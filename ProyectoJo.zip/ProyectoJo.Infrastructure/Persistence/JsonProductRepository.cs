﻿using System.Text.Json;
using ProyectoJo.Application.Ports.Out;
using ProyectoJo.Domain.Entities;

namespace ProyectoJo.Infrastructure.Persistence
{
	public class JsonProductRepository : IProductoRepository
	{
		private readonly string _rutaArchivo;

		public JsonProductRepository(string rutaArchivo)
		{
			_rutaArchivo = rutaArchivo;
		}

		public IEnumerable<Item> ObtenerTodos() => LeerJson();

		public IEnumerable<Item> ObtenerPorCategoria(string categoria) =>
			LeerJson().Where(i => i.Categoria == categoria);

		public List<Item> ObtenerMenu() => LeerJson();

		public void GuardarMenu(List<Item> menu)
		{
			var json = JsonSerializer.Serialize(menu, new JsonSerializerOptions { WriteIndented = true });
			File.WriteAllText(_rutaArchivo, json);
		}

		public void AgregarItem(Item item)
		{
			var menu = LeerJson();
			menu.Add(item);
			var json = JsonSerializer.Serialize(menu, new JsonSerializerOptions { WriteIndented = true });
			File.WriteAllText(_rutaArchivo, json);
		}

		private List<Item> LeerJson()
		{
			var json = File.ReadAllText(_rutaArchivo);
			return JsonSerializer.Deserialize<List<Item>>(json) ?? new List<Item>();
		}
		public Item? ObtenerPorId(int id) =>
			LeerJson().FirstOrDefault(i => i.Id == id);

		public void Eliminar(int id)
		{
			var menu = LeerJson();
			menu.RemoveAll(i => i.Id == id);
			GuardarMenu(menu);
		}
		public void ToggleActivo(int id)
		{
			var menu = LeerJson();
			var item = menu.FirstOrDefault(i => i.Id == id);
			if (item != null) item.Activo = !item.Activo;
			GuardarMenu(menu);
		}

		public void ToggleAgotado(int id)
		{
			var menu = LeerJson();
			var item = menu.FirstOrDefault(i => i.Id == id);
			if (item != null) item.Agotado = !item.Agotado;
			GuardarMenu(menu);
		}
	}
}